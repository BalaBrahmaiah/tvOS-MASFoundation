//
//  ViewController.h
//  SampleTvOSApp
//
//  Created by Akshay on 16/02/17.
//  Copyright © 2017 CA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

